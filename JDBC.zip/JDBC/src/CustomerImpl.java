import java.util.*;
import java.sql.*;

public class CustomerImpl implements CustomerOperation 
{
	Connection connection;
	static int price;
	
	public CustomerImpl() 
	{
		this.connection = Connectivity.establishConn();
	}
	@Override
	public int addCustomerDetails(CustomerDetails customer) 
	{
		int result = 0;
		try 
		{
			PreparedStatement ps = connection.prepareStatement("INSERT INTO CustomerData VALUES(?,?,?,?,?,?);");
			ps.setInt(1, customer.getId());
			ps.setString(2, customer.getName());
			ps.setString(3, customer.getEmail());
			ps.setLong(4, customer.getMobile());
			java.sql.Date jd = new java.sql.Date(customer.getEntryDate().getTime());
			ps.setDate(5, jd);
			ps.setString(6,customer.getLocation());
			result = ps.executeUpdate();
		} 
		catch (Exception e) 
		{
			System.out.println("Error in adding Customer...: " + e);
		}
		return result;
	}

	@Override
	public List<CustomerDetails> getAllCustomerDetails() 
	{
		List<CustomerDetails> cList = new ArrayList<>();
		try 
		{
			Statement st = connection.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM CustomerData;");
			while (rs.next()) 
			{
				CustomerDetails customer = new CustomerDetails(0, null, null, 0, null, null);
				customer.setId(rs.getInt(1));
				customer.setName(rs.getString(2));
				customer.setEmail(rs.getString(3));
				customer.setMobile(rs.getLong(4));
				customer.setEntryDate(rs.getDate(5));
				customer.setLocation(rs.getString(6));
				cList.add(customer);
			}
		} 
		catch (Exception e) 
		{
			System.out.println("Error in fetching all data  : " + e);
		}
		return cList;
	}

	@Override
	public List<CustomerDetails> getCustomerDetailsByDate() 
	{
		List<CustomerDetails> cList = new ArrayList<>();
		String date1;
		String date2;
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the first date:");
		date1=sc.nextLine();
		System.out.println("Enter the second date:");
		date2=sc.nextLine();
		CustomerDetails customer = new CustomerDetails(price, date2, date1, price, null, date2);
		try 
		{
			PreparedStatement pst = connection.prepareStatement("SELECT * FROM CustomerData WHERE entryDate BETWEEN ? AND ?;");
			java.sql.Date jd = new java.sql.Date(customer.getEntryDate().getTime());
			pst.setDate(1, jd);
			java.sql.Date jd1 = new java.sql.Date(customer.getEntryDate().getTime());
			pst.setDate(2, jd1);
			ResultSet rs = pst.executeQuery();
			if (rs.next()) 
			{
				customer.setId(rs.getInt(1));
				customer.setName(rs.getString(2));
				customer.setEmail(rs.getString(3));
				customer.setMobile(rs.getLong(4));
				customer.setEntryDate(rs.getDate(5));
				customer.setLocation(rs.getString(6));
				cList.add(customer);
			}
		} 
		catch (Exception e) 
		{
			System.out.println("Error in fetching the data : " + e);
		}
		return cList;
	}

	@Override
	public int updateCustomerDetails(CustomerDetails cus) 
	{
		int result = 0;
		try 
		{
			String qry = "UPDATE CustomerData SET email='?' WHERE id=?;";
			PreparedStatement ps = connection.prepareStatement(qry);
			ps.setString(1, cus.getEmail());
			ps.setInt(2, cus.getId());
		} 
		catch (Exception e) 
		{
			System.out.println("Error in Updating Data...: " + e);
		}
		return result;

	}

	@Override
	public int bookCustomerRoom() 
	{
		System.out.println("Choose a type of room: \n 1. AC Rooms \n 2. Non-AC Rooms");
		Scanner sc =new Scanner(System.in);
		int a=sc.nextInt();
		switch(a) 
		{
			case 1:
				price=1000;
				System.out.println("Choose the service you want: \n 1. Wifi \n 2. Laundry service");
				System.out.println("Select 3. For both Wifi and Laundry service");
				int b=sc.nextInt();
				switch(b) 
				{
					case 1:
						System.out.println("Thankyou for opting Wifi service ");
						price=price+150;
						break;
					case 2:
						System.out.println("Thankyou for opting Laundry service ");
						price=price+150;
						break;
					case 3:
						System.out.println("Thankyou for opting both Wifi and Laundry service");
						price=price+150+150;
						break;
				}
				break;
			case 2:
				price=700;
				System.out.println("Choose the service you want: \n 1. Wifi \n 2. Laundry service");
				System.out.println("Select 3. For both Wifi and Laundry service");
				int c=sc.nextInt();
				switch(c) 
				{
					case 1:
						System.out.println("Thankyou for opting Wifi service ");
						price=price+150;
						break;
					case 2:
						System.out.println("Thankyou for opting Laundry service ");
						price=price+150;
						break;
					case 3:
						System.out.println("Thankyou for opting both Wifi and Laundry service");
						price=price+150+150;
					break;
				}
				break;
		}
		return price;
	}
}
