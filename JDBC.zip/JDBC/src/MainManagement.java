import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainManagement 
{
	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) throws ParseException 
	{
		CustomerOperation cuOp = new CustomerImpl();
		do 
		{
			System.out.println("Select one of the Options given below : ");
			System.out.println("1. Register � Registers a Customer ");
			System.out.println("2. Book � Book a Room ");
			System.out.println("3. Check Status � Checks Room's Status ");
			System.out.println("4. Email � Update an email address of the customer ");
			System.out.println("5. All Bookings in a specific date ");
			System.out.println("6. All customers details ");
			System.out.println("7. Exit ");
			int option = scanner.nextInt();
			switch (option) 
			{
				case 1:
					CustomerDetails customer = inputMet();
					int result = cuOp.addCustomerDetails(customer);
					if (result > 0) 
					{
						System.out.println("Customer Details Added Successfully....");
					} 
					else 
					{
						System.out.println("Error in adding data....");
					}
					break;
				case 2:
					int p= cuOp.bookCustomerRoom();
					System.out.println("The total cost is: "+p);
					break;
				case 3:
					int i=0;
					List<CustomerDetails> cList = cuOp.getAllCustomerDetails();
					for(CustomerDetails people :cList) 
					{
						i++;
					}
					int room=9-i;
					if(room>0)
					{
						System.out.println("Number of vacant rooms are: "+room);
					}
					else
					{	
						System.out.println("No vacant room is available");
					}
					break;
				case 4:
					CustomerDetails cus = update();
					int result1 = cuOp.updateCustomerDetails(cus);
					if (result1 > 0) 
					{
						System.out.println("Customer Details Added Successfully....");
					} 	
					else 
					{
						System.out.println("Error in adding data....");
					}	
					break;
				case 5:
					List<CustomerDetails> cuList = cuOp.getCustomerDetailsByDate();
					for(CustomerDetails r :cuList) 
					{
						System.out.println(r);
					}	
					break;
				case 6:
					List<CustomerDetails> custList = cuOp.getAllCustomerDetails();
					for(CustomerDetails people :custList) 
					{
						System.out.println(people);
					}
					break;
				case 7:
					System.out.println("Thankyou for using our application ");
					System.out.println("HAVE A GREAT TIME ! ");
					break;
			}
			System.out.println(" 1. I would like to continue \n 2. I would like to exit");
		}while (scanner.nextInt() == 1);
	}
	static CustomerDetails inputMet() throws ParseException 
	{
		System.out.println("Enter Customer Details :");
		System.out.println("Enter your Name : ");
		String name = scanner.next();
		System.out.print("Enter your ID :");
		int id = scanner.nextInt();
		System.out.println("Enter your Mobile Number : ");
		long mobile = scanner.nextLong();
		System.out.println("Enter your Email Address : ");
		String email = scanner.next();
		System.out.println("Entry Date (dd/MM/yyyy) : ");
		String jd = scanner.next();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date entryDate = sdf.parse(jd);
		System.out.println("Enter the location : ");
		String location=scanner.next();
		CustomerDetails customer = new CustomerDetails(id, name, email, mobile, entryDate, location);
		return customer;
	}
	static CustomerDetails update() 
	{
		System.out.println("Enter the ID:");
		int id= scanner.nextInt();
		System.out.println("Enter the new Email Address : ");
		String email= scanner.next();
		CustomerDetails cus= new CustomerDetails(id, email);
		return cus;
	}
}
